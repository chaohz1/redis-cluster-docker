java -XX:+UseG1GC -XX:+UseContainerSupport -Xms4096m -Xmx4096m -server org.springframework.boot.loader.JarLauncher

